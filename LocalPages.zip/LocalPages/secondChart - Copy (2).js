var v2d1 = [8091, 30082, 37329, 29906, 21436, 9014, 5651];
var v2d2 = [14091, 29125, 38721, 27081, 22612, 8691, 5812];
var v2d3 = [8622, 31775, 40076, 33558, 22174, 8814, 5766];
var ageGrp = ["Less than 18", "18 - 25", "26 - 35", "36 - 45", "46 - 60", "Above 60", "Age Unknown"];

//var v2data = [{"xxx": 100, "xxx": 100, "xxx": 100, }

var v2data = [
				["Less than 18", "18-25", "26-35", "36-45", "46-60", "Above 60", "Age Unknown"],
				[8091, 30082, 37329, 29906, 21436, 9014, 5651],
				[14091, 29125, 38721, 27081, 22612, 8691, 5812],
				[8622, 31775, 40076, 33558, 22174, 8814, 5766]
			 ]

/*
var v2data = [
    { ageGrp: 'Firearms', y2014: 8091,  y2015: 14091, y2016: 8622  },
    { ageGrp: 'Firearms', y2014: 30082, y2015: 29125, y2016: 31775 },
    { ageGrp: 'Firearms', y2014: 37329, y2015: 38721, y2016: 40076 },
    { ageGrp: 'Firearms', y2014: 29906, y2015: 27081, y2016: 33558 },
    { ageGrp: 'Firearms', y2014: 21436, y2015: 22612, y2016: 22174 },
    { ageGrp: 'Firearms', y2014: 9014,  y2015: 8691,  y2016: 8814  },
    { ageGrp: 'Firearms', y2014: 5651,  y2015: 5812,  y2016: 5766  }
] 
*/
			 
var margin = {top: 100, right: 10, bottom: 80, left: 120},
	width = +svg.attr("width") - margin.left - margin.right,
    height = +svg.attr("height") - margin.top - margin.bottom,
	radius = Math.min(width, height) / 2;

// var v2color = ["#98abc5", "#8a89a6", "#7b6888", "#6b486b", "#a05d56", "#d0743c", "#ff8c00"];

/*
var v2color = ["#6388b4", "#ffae34", "#ef6f6a", "#8cc2ca", 
				"#55ad89", "#c3bc3f", "#767676"];
*/

var v2color = ["#2ec7c9", "#ffb980", "#d87a80", "#5ab1ef", 
				"#97b552", "#e5cf0d", "#8d98b3"];
				
/*
rbg(46,199,201),  #2ec7c9
rbg(255,185,128), #ffb980
rbg(216,122,128), #d87a80
rbg(90,177,239),  #5ab1ef
rbg(151,181,82),  #97b552
rbg(229,207,13),  #e5cf0d
rbg(141,152,179)  #8d98b3
*/
		
/*
var v2color = [
rgb(99, 136, 180), // #6388b4
rgb(255, 174, 52),// #ffae34
rgb(239, 111, 106),// #ef6f6a
rgb(140, 194, 202),// #8cc2ca
rgb(85, 173, 137),// #55ad89
rgb(195, 188, 63),// #c3bc3f
rgb(118, 118, 118)// #767676
];
*/

var arc = d3.arc()
    .outerRadius(radius - 75)
    .innerRadius(radius +10);

var pie = d3.pie()
    .sort(null)
    .value(function(d, i) { 
			//console.log(d);
			return d; 
			});

var svg = d3.select(".viz2");

var tooltip2 = d3.select("body")
					.append("div")
					.attr("class", "toolTip2")
					.style("opacity", 0)
				;

var arcOver = d3.arc()
    .innerRadius(radius +10 + 20)
    .outerRadius(radius - 75 - 7)
	;

// title
svg.append("text")     
  .attr("class", "viz1title")
  .attr("transform",
		"translate(" + ((width+120)/2)  + " ," + 
					   (20) + ")")
  .style("text-anchor", "middle")
  .text("# of Road Accident Deaths by Age Group");

  
// legends START 
//console.log(+svg.attr("width"));

var tmpOffsetW = 15;
var tmpOffsetH = +svg.attr("height")/2 - 25;

for (var i = 0; i < ageGrp.length; i++) {
	svg.append("rect").attr("class","legendRect").attr("height",10).attr("width",10)
		.attr("x",tmpOffsetW).attr("y",tmpOffsetH+(i*20)).attr("fill", v2color[i])	;
		
	svg.append("text").attr("class", "legendviz2")
		.style("fill", "#505151").style("stroke-width", "20px").style("text-anchor", "start")
		.attr("x",tmpOffsetW+15).attr("y",tmpOffsetH+9+(i*20)).text(ageGrp[i])	;
}

// legends END 


// buttons START
//console.log(((+svg.attr("weight"))/2));
tmpOffsetW = 350-140;
tmpOffsetH = 70;

btn2014 = svg.append("rect").attr("class","yearButtonviz2").attr("height",30).attr("width",70).attr("fill","white")
	.attr("x",tmpOffsetW).attr("y",tmpOffsetH).attr("rx",6).attr('stroke', '#029bce').attr('stroke-width', 2)
/*	.on("mouseover",function(){
		d3.select(this).transition().duration(500).attr("fill","#029bce");
		lbl2014.transition().duration(100).delay(100).style("fill", "white")
		})
	.on("mouseout", function(){ 
		d3.select(this).transition().duration(100).delay(100).attr("fill","white");
		lbl2014.transition().duration(100).delay(100).style("fill", "#029bce")
		}) */
	.on("click",function(){
		d3.select(this).transition().duration(300).attr("fill","#029bce");  //017aa3
		lbl2014.transition().duration(100).delay(100).style("fill", "white");
		chart2014();
		})
	;

lbl2014 = svg.append("text").attr("class", "yearButtonviz2Label")  //505151
	.style("fill", "#029bce").style("stroke-width", "40px").style("font-weight","bold")
	.style("text-anchor", "start")
	.attr("x",tmpOffsetW+17).attr("y",tmpOffsetH+20).text("2014")	;	

tmpOffsetW = tmpOffsetW + 70 + 35;
tmpOffsetH = tmpOffsetH;

btn2015 = svg.append("rect").attr("class","yearButtonviz2").attr("height",30).attr("width",70).attr("fill","white")
	.attr("x",tmpOffsetW).attr("y",tmpOffsetH).attr("rx",6).attr('stroke', '#029bce').attr('stroke-width', 2)
	.on("click",function(){
		d3.select(this).transition().duration(300).attr("fill","#029bce");  //017aa3
		lbl2015.transition().duration(100).delay(100).style("fill", "white");
		chart2015();
		})
	;

lbl2015 = svg.append("text").attr("class", "yearButtonviz2Label")  //505151
	.style("fill", "#029bce").style("stroke-width", "40px").style("font-weight","bold")
	.style("text-anchor", "start")
	.attr("x",tmpOffsetW+17).attr("y",tmpOffsetH+20).text("2015")	;	
	
	
tmpOffsetW = tmpOffsetW + 70 + 35;
tmpOffsetH = tmpOffsetH;

btn2016 = svg.append("rect").attr("class","yearButtonviz2").attr("height",30).attr("width",70).attr("fill","white")
	.attr("x",tmpOffsetW).attr("y",tmpOffsetH).attr("rx",6).attr('stroke', '#029bce').attr('stroke-width', 2)
	.on("click",function(){
		d3.select(this).transition().duration(300).attr("fill","#029bce");  //017aa3
		lbl2016.transition().duration(100).delay(100).style("fill", "white");
		chart2016();
		})
	;

lbl2016 = svg.append("text").attr("class", "yearButtonviz2Label")  //505151
	.style("fill", "#029bce").style("stroke-width", "40px").style("font-weight","bold")
	.style("text-anchor", "start")
	.attr("x",tmpOffsetW+17).attr("y",tmpOffsetH+20).text("2016")	;	

// buttons END


// functions for different year START
function chart2014(){
	btn2015.transition().duration(100).delay(100).attr("fill","white");
	lbl2015.transition().duration(100).delay(100).style("fill", "#029bce");
	btn2016.transition().duration(100).delay(100).attr("fill","white");
	lbl2016.transition().duration(100).delay(100).style("fill", "#029bce");	
	console.log("Display chart for year - 2014");
	change(v2d1);
}

function chart2015(){
	btn2014.transition().duration(100).delay(100).attr("fill","white");
	lbl2014.transition().duration(100).delay(100).style("fill", "#029bce");
	btn2016.transition().duration(100).delay(100).attr("fill","white");
	lbl2016.transition().duration(100).delay(100).style("fill", "#029bce");	
	console.log("Display chart for year - 2015");
	//
	//var tmppath = d3.selectAll("path").data(pie(v2d2));
//	tmppath.transition().duration(750).attrTween("d", arcTween); // redraw the arcs
	change(v2d2);

}

function chart2016(){
	btn2014.transition().duration(100).delay(100).attr("fill","white");
	lbl2014.transition().duration(100).delay(100).style("fill", "#029bce");
	btn2015.transition().duration(100).delay(100).attr("fill","white");
	lbl2015.transition().duration(100).delay(100).style("fill", "#029bce");	
	console.log("Display chart for year - 2016");
	change(v2d3);
}
// functions for different year END

function tooltiptext2(d,i) {
 var text = "<strong><span style='color:#4c4a4a'>Age Group:</span></strong> <span style='color:#7a3402'>" + ageGrp[i] + "</span><br>" + "<strong><span style='color:#4c4a4a'>Death Count: </span></strong> <span style='color:#7a3402'>" + d3.format(",")(d) + "</span><br>" ;
	return text;
}	

/*
var g = svg.selectAll(".arc")
			.data(pie(v2d3)).enter().append("g").attr("class", "arc")
			.attr("transform", "translate(" + ((svg.attr("width") / 2) ) + "," + ((svg.attr("height") / 2) + 50) + ")");
		
g.append("path").transition().duration(500).delay(500)
  .attr("d", arc).style("stroke","white").style("stroke-width",2)
  .style("fill", function(d, i) { return v2color[i]; });
*/

var path = svg.selectAll("path")
    .data(pie(v2d3))
    .enter()
    .append("path");

path.transition()
    .duration(500)
    .attr("fill", function(d, i) {
        return v2color[i];
    })
	.attr("transform", "translate(" + ((svg.attr("width") / 2) ) + "," + ((svg.attr("height") / 2) + 50) + ")")
    .attr("d", arc)
	.style("stroke","white").style("stroke-width",2)
    .each(function(d) {
        this._current = d;
    }); // store the initial angles

function change(data) {
    path.data(pie(data));
    path.transition().duration(750).attrTween("d", arcTween); // redraw the arcs
}

function arcTween(a) {
    var i = d3.interpolate(this._current, a);
    this._current = i(0);
    return function(t) {
        return arc(i(t));
    };
}

d3.selectAll("path")
    .on("mouseover", function(d, i){
	        tooltip2.transition().duration(200).style("opacity", .9);
			tooltip2.html(tooltiptext2(d.data, d.index)).style("left", (d3.event.pageX + 3) + "px")
              .style("top", (d3.event.pageY - 38) + "px").style("display", "inline-block");  // 
			d3.select(this).transition().attr("d", arcOver).duration(500);  
        })
    .on("mouseout", function(d){ 
			tooltip2.transition().duration(1).style("opacity", 0);
			d3.select(this).transition().attr("d", arc).duration(500);
			});

btn2016.attr("fill","#029bce");  //017aa3
lbl2016.style("fill", "white");
